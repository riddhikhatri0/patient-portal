import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const DoctorLoginPage = () => {
    const [formData, setFormData] = useState({ username: '', password: '' });
    const navigate = useNavigate();
    const onChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });
    const onSubmit = async e => {
        e.preventDefault();
        try {
            const res = await axios.post('http://localhost:5000/api/auth/login/doctor', formData);
            localStorage.setItem('token', res.data.token);
            navigate('/dashboard-doctor');
        } catch (err) { alert(err.response.data.msg); }
    };
    return (
        <div className="form-container">
            <h2>Doctor Login</h2>
            <form onSubmit={onSubmit}>
                <input type="text" placeholder="Username" name="username" onChange={onChange} required />
                <input type="password" placeholder="Password" name="password" onChange={onChange} required />
                <button type="submit" className="btn btn-primary">Login</button>
            </form>
        </div>
    );
};
export default DoctorLoginPage;