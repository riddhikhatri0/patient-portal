// models/Doctor.js
const mongoose = require('mongoose');

const DoctorSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

// IMPORTANT: In a real app, you wouldn't let doctors register themselves.
// An admin would create their accounts. For now, you can manually add
// a doctor to your MongoDB database for testing.
module.exports = mongoose.model('Doctor', DoctorSchema);